from flask import Flask
import random

app = Flask(__name__)

# Lista de fatos
facts_list = [
    "A maioria das pessoas que sofrem de dependência tecnológica sente um forte estresse quando está fora da rede.",
    "Mais de 50% das pessoas entre 18 e 34 anos se consideram dependentes de seus smartphones.",
    "O estudo da dependência tecnológica é uma das áreas mais relevantes da pesquisa científica moderna.",
    "Mais de 60% das pessoas respondem a mensagens de trabalho em até 15 minutos após sair do serviço.",
    "Uma forma de combater a dependência é buscar atividades offline que tragam prazer.",
    "As redes sociais são projetadas para nos manter dentro da plataforma o máximo de tempo possível.",
    "Elon Musk defende a regulamentação das redes sociais e proteção de dados.",
    "Devemos estar conscientes dos pontos positivos e negativos das redes sociais."
]

# ROTA 1: Página Inicial (Home)
@app.route("/")
def home():
    # Aqui retornamos um Título e um Link (a tag <a>)
    return '''
    <h1>Olá! Esta é a página inicial.</h1>
    <a href="/random_fact">Clique aqui para ver um fato aleatório!</a>
    '''

# ROTA 2: Página do Fato (Onde a mágica acontece)
@app.route("/random_fact")
def fact():
    return f'<h1>{random.choice(facts_list)}</h1>'

app.run(debug=True)